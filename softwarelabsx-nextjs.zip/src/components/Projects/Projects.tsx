'use client'

import Image from 'next/image'
import Link from 'next/link'
import styles from './Projects.module.css'

const projects = [
  {
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80',
    tags: ['Web App', 'Dashboard'],
    title: 'Dashboard Analytics',
    description: 'Plataforma de análise de dados em tempo real com visualizações interativas e relatórios automatizados.',
  },
  {
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=800&q=80',
    tags: ['Mobile', 'E-commerce'],
    title: 'App E-commerce',
    description: 'Aplicativo mobile completo para marketplace com integração de pagamentos e gestão de pedidos.',
  },
  {
    image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=800&q=80',
    tags: ['IA', 'Computer Vision'],
    title: 'Inspeção Industrial',
    description: 'Sistema de visão computacional para controle de qualidade automatizado em linha de produção.',
  },
]

export default function Projects() {
  return (
    <section className={styles.projects} id="projetos">
      <div className="container">
        <div className={styles.header}>
          <div>
            <span className="section-label">Portfólio</span>
            <h2 className="section-title">Projetos em Destaque</h2>
          </div>
          <Link href="/projetos" className="btn btn-secondary hide-mobile">
            Ver Todos os Projetos
          </Link>
        </div>

        <div className={styles.grid}>
          {projects.map((project) => (
            <article key={project.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <Image
                  src={project.image}
                  alt={project.title}
                  width={800}
                  height={450}
                  className={styles.image}
                />
              </div>
              <div className={styles.content}>
                <div className={styles.tags}>
                  {project.tags.map((tag) => (
                    <span key={tag} className={styles.tag}>{tag}</span>
                  ))}
                </div>
                <h3 className={styles.cardTitle}>{project.title}</h3>
                <p className={styles.cardDescription}>{project.description}</p>
              </div>
            </article>
          ))}
        </div>

        <div className={styles.mobileAction}>
          <Link href="/projetos" className="btn btn-secondary hide-desktop">
            Ver Todos os Projetos
          </Link>
        </div>
      </div>
    </section>
  )
}
