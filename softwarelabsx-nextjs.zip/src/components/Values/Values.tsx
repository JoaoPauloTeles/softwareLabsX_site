'use client'

import styles from './Values.module.css'

const values = [
  {
    icon: '⭐',
    title: 'Excelência',
    description: 'Compromisso com a qualidade em cada detalhe, buscando sempre superar as expectativas.',
  },
  {
    icon: '🤝',
    title: 'Integridade',
    description: 'Honestidade, ética e transparência em todas as nossas relações e decisões.',
  },
  {
    icon: '👥',
    title: 'Colaboração',
    description: 'Trabalho em equipe para alcançar resultados extraordinários juntos.',
  },
  {
    icon: '🎯',
    title: 'Cliente no Centro',
    description: 'Foco total em entender e superar as necessidades de cada cliente.',
  },
]

export default function Values() {
  return (
    <section className={styles.values}>
      <div className="container">
        <div className={styles.header}>
          <span className="section-label">Nossos Valores</span>
          <h2 className="section-title">O que nos Define</h2>
          <p className="section-subtitle">
            Princípios que guiam cada decisão e cada linha de código que escrevemos.
          </p>
        </div>

        <div className={styles.grid}>
          {values.map((value) => (
            <article key={value.title} className={styles.card}>
              <div className={styles.icon}>{value.icon}</div>
              <h3 className={styles.cardTitle}>{value.title}</h3>
              <p className={styles.cardDescription}>{value.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
