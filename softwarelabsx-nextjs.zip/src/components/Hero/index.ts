export { default } from './Hero'
