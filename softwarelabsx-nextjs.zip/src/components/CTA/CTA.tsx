'use client'

import Link from 'next/link'
import styles from './CTA.module.css'

export default function CTA() {
  return (
    <section className={styles.cta}>
      <div className="container">
        <div className={styles.content}>
          <span className="section-label">Pronto para Começar?</span>
          <h2 className="section-title">
            Vamos Construir o<br />Futuro Juntos
          </h2>
          <p className="section-subtitle">
            Entre em contato conosco e descubra como podemos 
            transformar suas ideias em soluções tecnológicas de sucesso.
          </p>
          <div className={styles.actions}>
            <Link href="#contato" className="btn btn-primary">
              Iniciar Conversa
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </Link>
            <Link href="tel:+5541987165869" className="btn btn-secondary">
              📞 (41) 98716-5869
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
