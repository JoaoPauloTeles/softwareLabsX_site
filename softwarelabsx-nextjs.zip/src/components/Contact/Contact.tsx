'use client'

import { useState, FormEvent } from 'react'
import styles from './Contact.module.css'

const contactMethods = [
  {
    icon: '📞',
    label: 'Telefone',
    value: '(41) 98716-5869',
    href: 'tel:+5541987165869',
  },
  {
    icon: '📞',
    label: 'Telefone Alternativo',
    value: '(41) 99658-1513',
    href: 'tel:+5541996581513',
  },
  {
    icon: '✉️',
    label: 'E-mail',
    value: 'contato@softwarelabs.pro',
    href: 'mailto:contato@softwarelabs.pro',
  },
]

export default function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simula envio do formulário
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setSubmitted(true)

    // Reset form
    const form = e.target as HTMLFormElement
    form.reset()

    // Reset submitted state after 5 seconds
    setTimeout(() => setSubmitted(false), 5000)
  }

  return (
    <section className={styles.contact} id="contato">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.info}>
            <span className="section-label">Contato</span>
            <h2 className={styles.title}>Vamos Conversar?</h2>
            <p className={styles.description}>
              Estamos prontos para ouvir suas ideias e ajudar a transformá-las 
              em soluções digitais inovadoras. Entre em contato por qualquer 
              um dos nossos canais.
            </p>

            <div className={styles.methods}>
              {contactMethods.map((method) => (
                <div key={method.label} className={styles.method}>
                  <div className={styles.methodIcon}>{method.icon}</div>
                  <div className={styles.methodText}>
                    <span className={styles.methodLabel}>{method.label}</span>
                    <a href={method.href} className={styles.methodValue}>
                      {method.value}
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.formRow}>
              <div className={styles.formGroup}>
                <label htmlFor="name">Nome</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  placeholder="Seu nome completo"
                  required
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="phone">Telefone</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  placeholder="(00) 00000-0000"
                />
              </div>
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="email">E-mail</label>
              <input
                type="email"
                id="email"
                name="email"
                placeholder="seu@email.com"
                required
              />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="message">Mensagem</label>
              <textarea
                id="message"
                name="message"
                placeholder="Conte-nos sobre seu projeto..."
                required
              />
            </div>

            <button
              type="submit"
              className={`btn btn-primary ${styles.submitBtn}`}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <span className={styles.spinner} />
                  Enviando...
                </>
              ) : submitted ? (
                <>
                  ✓ Mensagem Enviada!
                </>
              ) : (
                <>
                  Enviar Mensagem
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
                  </svg>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </section>
  )
}
