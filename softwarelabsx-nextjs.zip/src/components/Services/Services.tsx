'use client'

import Link from 'next/link'
import styles from './Services.module.css'

const services = [
  {
    icon: '🌐',
    title: 'Aplicativos Web',
    description: 'Desenvolvimento de aplicações web modernas, responsivas e escaláveis utilizando as tecnologias mais avançadas do mercado.',
  },
  {
    icon: '📱',
    title: 'Aplicativos Mobile',
    description: 'Apps nativos e híbridos para iOS e Android com experiências de usuário excepcionais e performance otimizada.',
  },
  {
    icon: '👁️',
    title: 'Visão Computacional',
    description: 'Sistemas inteligentes de processamento de imagem e vídeo para automação, análise e reconhecimento de padrões.',
  },
  {
    icon: '🤖',
    title: 'Inteligência Artificial',
    description: 'Soluções de IA e Machine Learning personalizadas para otimizar processos e extrair insights valiosos dos dados.',
  },
]

export default function Services() {
  return (
    <section className={styles.services} id="servicos">
      <div className="container">
        <div className={styles.header}>
          <span className="section-label">Nossos Serviços</span>
          <h2 className="section-title">
            Soluções que Impulsionam<br />seu Negócio
          </h2>
          <p className="section-subtitle">
            Oferecemos um portfólio completo de serviços de desenvolvimento 
            de software para atender às suas necessidades específicas.
          </p>
        </div>

        <div className={styles.grid}>
          {services.map((service) => (
            <article key={service.title} className={styles.card}>
              <div className={styles.icon}>{service.icon}</div>
              <h3 className={styles.cardTitle}>{service.title}</h3>
              <p className={styles.cardDescription}>{service.description}</p>
              <Link href="#contato" className={styles.link}>
                Saiba mais
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </Link>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
